# OpenWrt LuCI Fan UI (Custom)

Custom dark-mode LuCI panel for fan PWM control with:
- Manual PWM and presets (`quiet`, `balanced`, `turbo`)
- Driver auto mode restore (`apply_auto`)
- Live temperature/PWM status

## Package content

- `htdocs/luci-static/resources/view/system/fan_control.js` - UI
- `root/usr/bin/fan-control-rpc` - backend RPC shell helper
- `root/etc/config/fancontrol` - default config
- `root/usr/share/rpcd/acl.d/luci-app-fan-control.json` - ACL
- `root/usr/share/luci/menu.d/zz-fancontrol-override.json` - single menu entry override (`admin/services/fancontrol`)

## Install to router

From macOS/Linux host:

```bash
./scripts/install-to-router.sh 192.168.50.1
```

Then open:

`http://192.168.50.1/cgi-bin/luci/admin/services/fancontrol`

## Self-test on router

```bash
./scripts/selftest-router.sh 192.168.50.1
```

This checks:
- deployed files exist
- RPC `status` response
- manual/auto actions are callable

## Build backup archive

```bash
mkdir -p dist
tar -czf dist/luci-app-fan-control-backup.tar.gz Makefile htdocs root scripts README.md
```

Use this archive to restore on new routers later.

